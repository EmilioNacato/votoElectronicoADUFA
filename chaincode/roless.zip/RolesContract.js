'use strict';

process.env['TNS_ADMIN'] = '/home/ubuntu/votoElectronicoADUFA/Wallet_votoElectronicoBD';
process.env['NODE_EXTRA_CA_CERTS'] = '/home/ubuntu/votoElectronicoADUFA/Wallet_votoElectronicoBD/ewallet.pem';

console.log('TNS_ADMIN:', process.env.TNS_ADMIN);
console.log('NODE_EXTRA_CA_CERTS:', process.env.NODE_EXTRA_CA_CERTS);

const { Contract } = require('fabric-contract-api');
const oracledb = require('oracledb');

// Configuración de la base de datos
const dbConfig = {
  user: 'ADMIN', // Usuario de la base de datos
  password: 'xXsCzXQj@S39', // Contraseña del usuario de la base de datos
  connectString: 'votoelectronicobd_high' // Usar el alias del tnsnames.ora
};

class RolesContract extends Contract {
  async queryRole(ctx, roleId) {
    console.log(`queryRole invoked with roleId: ${roleId}`);
    
    // Conectar a la base de datos y realizar la consulta
    let connection;
    try {
      console.log('Attempting to connect to the database...');
      connection = await oracledb.getConnection(dbConfig);
      console.log('Connected to the database.');

      const query = 'SELECT * FROM ROL WHERE ID_ROL = :id';
      console.log(`Executing query: ${query} with roleId: ${roleId}`);
      const result = await connection.execute(query, [roleId]);

      if (result.rows.length === 0) {
        console.log(`Role with ID ${roleId} does not exist`);
        throw new Error(`${roleId} does not exist`);
      }

      const role = {
        id: result.rows[0][0],
        nombre_rol: result.rows[0][1],
        crear_votacion: result.rows[0][2],
        ver_resultados: result.rows[0][3]
      };
      console.log(`Role found: ${JSON.stringify(role)}`);
      return JSON.stringify(role);
    } catch (err) {
      console.error(`Error querying role: ${err.message}`);
      throw new Error(`Error querying role: ${err.message}`);
    } finally {
      if (connection) {
        try {
          console.log('Closing database connection...');
          await connection.close();
          console.log('Database connection closed.');
        } catch (err) {
          console.error(`Error closing the database connection: ${err.message}`);
        }
      }
    }
  }

  async createRole(ctx, id, nombre_rol, crear_votacion, ver_resultados) {
    console.info('============= START : Create Role ===========');
    console.log(`Creating role with ID: ${id}, nombre_rol: ${nombre_rol}, crear_votacion: ${crear_votacion}, ver_resultados: ${ver_resultados}`);

    const role = {
      id,
      nombre_rol,
      crear_votacion,
      ver_resultados
    };

    try {
      await ctx.stub.putState(id, Buffer.from(JSON.stringify(role)));
      console.info(`Role created successfully: ${JSON.stringify(role)}`);
    } catch (err) {
      console.error(`Error creating role: ${err.message}`);
      throw new Error(`Error creating role: ${err.message}`);
    }
    console.info('============= END : Create Role ===========');
  }

  // Nuevo método para inicializar roles
  async initLedger(ctx) {
    console.info('============= START : Initialize Ledger ===========');
    const todo = [
        {
            description: 'Learn Hyperledger',
            completed: true,
        },
        {
            description: 'Connect Api to Hyperledger',
            completed: true,
        },
        {
            description: 'Create New todo smart contract',
            completed: true,
        },
        {
            description: 'Connect todo app to api',
            completed: true,
        },
        {
            description: 'Connect todo api to ui',
            completed: true,
        },
        
    ];

    // for (let i = 0; i < todo.length; i++) {
    //     todo[i].docType = 'todo';
    //     await ctx.stub.putState('TODO' + i, Buffer.from(JSON.stringify(todo[i])));
    //     console.info('Added <--> ', todo[i]);
    // }
    console.info('============= END : Initialize Ledger ===========');
  }
}
module.exports = RolesContract;
